const Thanks = () => {
  return <div style={{marginTop: '30px'}}>
    <p>Terima kasih telah berpartisipasi dalam tes ini!</p>
  </div>
}

export default Thanks;