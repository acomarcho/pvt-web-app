import styles from './info.module.css';

const Information = () => {
  return <div className={styles.infoContainer}>
    <p>Ikut berpartisipasi dalam tes ini dengan cara mengisi formulir di bawah!</p>
  </div>
}

export default Information;