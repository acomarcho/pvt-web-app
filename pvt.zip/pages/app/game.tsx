import Header from "../../components/header";
import GameComponent from "../../components/game/game";

const Game = () => {
  return (
    <>
      <GameComponent />
    </>
  );
};

export default Game;
